<?php
/**
 * Plugin Name: Easytools Email Tester
 * Description: Simple plugin to test email delivery for Easytools Subscription Manager
 * Version: 1.0
 * Author: Test Plugin
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Easytools_Email_Test_Plugin {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'add_test_page'));
        add_action('admin_post_test_email_creation', array($this, 'handle_test'));
    }

    public function add_test_page() {
        add_menu_page(
            'Email Tester',
            '🧪 Email Test',
            'manage_options',
            'easytools-email-test',
            array($this, 'render_test_page'),
            'dashicons-email',
            99
        );
    }

    public function render_test_page() {
        $logs = get_option('easytools_email_test_logs', array());
        ?>
        <div class="wrap">
            <h1>🧪 Easytools Email Delivery Test</h1>

            <div style="background: white; padding: 20px; margin: 20px 0; border-left: 4px solid #00a0d2;">
                <h2>What This Does</h2>
                <ol>
                    <li>Creates a test user account (username: <code>emailtest_[timestamp]</code>)</li>
                    <li>Sends custom HTML welcome email using your Easytools email settings</li>
                    <li>Shows detailed logs of the entire process</li>
                    <li>Allows you to verify email delivery</li>
                </ol>
            </div>

            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="background: white; padding: 20px; margin: 20px 0;">
                <input type="hidden" name="action" value="test_email_creation">
                <?php wp_nonce_field('test_email_creation', 'test_nonce'); ?>

                <table class="form-table">
                    <tr>
                        <th><label for="test_email">Test Email Address:</label></th>
                        <td>
                            <input type="email" id="test_email" name="test_email"
                                   value="<?php echo esc_attr(wp_get_current_user()->user_email); ?>"
                                   class="regular-text" required>
                            <p class="description">Email address where the welcome email will be sent</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="delete_after">Delete User After Test:</label></th>
                        <td>
                            <label>
                                <input type="checkbox" id="delete_after" name="delete_after" value="1" checked>
                                Automatically delete test user after sending email
                            </label>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" class="button button-primary button-hero">
                        🚀 Create User & Send Email
                    </button>
                </p>
            </form>

            <?php if (!empty($logs)): ?>
            <div style="background: #f5f5f5; padding: 20px; margin: 20px 0; border-radius: 4px;">
                <h2>Test Results</h2>
                <div style="background: #1e1e1e; color: #d4d4d4; padding: 15px; border-radius: 4px; font-family: monospace; font-size: 13px; overflow-x: auto;">
                    <?php foreach (array_reverse($logs) as $log): ?>
                        <div style="margin-bottom: 8px;">
                            <span style="color: #858585;">[<?php echo esc_html($log['time']); ?>]</span>
                            <span style="color: <?php echo $log['type'] === 'error' ? '#f48771' : ($log['type'] === 'success' ? '#89d185' : '#4ec9b0'); ?>">
                                <?php echo esc_html($log['message']); ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p>
                    <a href="<?php echo admin_url('admin.php?page=easytools-email-test&clear_logs=1'); ?>"
                       class="button" onclick="return confirm('Clear all test logs?');">
                        Clear Logs
                    </a>
                </p>
            </div>
            <?php endif; ?>
        </div>

        <style>
            .button-hero {
                padding: 15px 30px !important;
                height: auto !important;
                font-size: 16px !important;
            }
        </style>
        <?php

        // Handle clear logs
        if (isset($_GET['clear_logs'])) {
            delete_option('easytools_email_test_logs');
            echo '<script>window.location.href = "' . admin_url('admin.php?page=easytools-email-test') . '";</script>';
        }
    }

    public function handle_test() {
        // Verify nonce
        if (!isset($_POST['test_nonce']) || !wp_verify_nonce($_POST['test_nonce'], 'test_email_creation')) {
            wp_die('Security check failed');
        }

        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $test_email = sanitize_email($_POST['test_email']);
        $delete_after = isset($_POST['delete_after']);

        $this->log('info', '========== NEW TEST STARTED ==========');
        $this->log('info', 'Test email: ' . $test_email);
        $this->log('info', 'Delete after: ' . ($delete_after ? 'Yes' : 'No'));

        // Generate unique username
        $username = 'emailtest_' . time();
        $this->log('info', 'Generated username: ' . $username);

        // Create user
        $this->log('info', 'Creating WordPress user...');
        $password = wp_generate_password(12, true, true);
        $user_id = wp_create_user($username, $password, $test_email);

        if (is_wp_error($user_id)) {
            $this->log('error', 'Failed to create user: ' . $user_id->get_error_message());
            wp_redirect(admin_url('admin.php?page=easytools-email-test'));
            exit;
        }

        $this->log('success', 'User created successfully! User ID: ' . $user_id);

        // Check if Easytools Email Handler exists
        $this->log('info', 'Checking for Easytools Email Handler...');

        if (!class_exists('Easytools_Email_Handler')) {
            $this->log('error', 'Easytools_Email_Handler class not found!');
            $this->log('error', 'Make sure Easytools Subscription Manager plugin is active');

            if ($delete_after) {
                wp_delete_user($user_id);
                $this->log('info', 'Test user deleted');
            }

            wp_redirect(admin_url('admin.php?page=easytools-email-test'));
            exit;
        }

        $this->log('success', 'Easytools_Email_Handler class found');

        // Get email handler instance
        $this->log('info', 'Getting email handler instance...');
        $email_handler = Easytools_Email_Handler::get_instance();
        $this->log('success', 'Email handler instance created');

        // Send email
        $this->log('info', 'Attempting to send welcome email...');
        $this->log('info', 'Email parameters: user_id=' . $user_id . ', email=' . $test_email . ', username=' . $username);

        $result = $email_handler->send_new_user_email($user_id, $test_email, $username);

        if ($result) {
            $this->log('success', '✅ EMAIL SENT SUCCESSFULLY!');
            $this->log('success', 'Check your inbox at: ' . $test_email);
            $this->log('info', 'Don\'t forget to check spam folder!');
        } else {
            $this->log('error', '❌ EMAIL FAILED TO SEND!');
            $this->log('error', 'Check WordPress debug.log for wp_mail errors');
            $this->log('error', 'Check SMTP plugin settings if you use one');
        }

        // Delete user if requested
        if ($delete_after) {
            $this->log('info', 'Deleting test user...');
            require_once(ABSPATH . 'wp-admin/includes/user.php');
            wp_delete_user($user_id);
            $this->log('success', 'Test user deleted');
        } else {
            $this->log('info', 'Test user kept: ' . $username . ' (ID: ' . $user_id . ')');
        }

        $this->log('info', '========== TEST COMPLETED ==========');

        // Redirect back
        wp_redirect(admin_url('admin.php?page=easytools-email-test'));
        exit;
    }

    private function log($type, $message) {
        $logs = get_option('easytools_email_test_logs', array());

        $logs[] = array(
            'time' => current_time('Y-m-d H:i:s'),
            'type' => $type,
            'message' => $message
        );

        // Keep only last 50 log entries
        if (count($logs) > 50) {
            $logs = array_slice($logs, -50);
        }

        update_option('easytools_email_test_logs', $logs);

        // Also log to error_log for debugging
        error_log('Easytools Email Test [' . strtoupper($type) . ']: ' . $message);
    }
}

// Initialize the plugin
Easytools_Email_Test_Plugin::get_instance();
